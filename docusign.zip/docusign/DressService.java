package docusign;
/*
 Author: Aditya Prabhu
 Language: Java
  */
import java.util.ArrayList;
import java.util.List;

public class DressService 
{
	private static DresserInterface dresser;
	private static List<String> completedCommands= new ArrayList<>();
	private static String failMessage="fail";
	private static StringBuilder dressOrder = new StringBuilder();

	public String runService(List<String>lst)
	{
		try
		{
			switch(lst.get(0).toUpperCase())
			{
			case "HOT":
				dresser = new HotDresser();
				break;
			case "COLD":
				dresser = new ColdDresser();
				break;
			default:
				throw new IllegalArgumentException("Invalid temperature type specified in the first argument!");
			}
		}
		catch(IllegalArgumentException ex)
		{
			return ex.getMessage();
		}

		try
		{
			for(int i=1; i< lst.size();i++)
			{
				String command = lst.get(i);
				if(isValidCommand(command))
				{
					switch(command)
					{
					case "1":
						dressOrder.append(", ").append(dresser.putOnFootwear());
						break;
					case "2":
						dressOrder.append(", ").append(dresser.putOnHeadwear());
						break;
					case "3":
						dressOrder.append(", ").append(dresser.putOnSocks());
						break;
					case "4":
						dressOrder.append(", ").append(dresser.putOnShirt());
						break;
					case "5":
						dressOrder.append(", ").append(dresser.putOnJacket());
						break;
					case "6":
						dressOrder.append(", ").append(dresser.putOnPants());
						break;
					case "7":
						dressOrder.append(", ").append(dresser.leaveHouse());
						break;
					case "8":
						dressOrder.append(", ").append(dresser.takeOffPajamas());
						break;
					}
				}	
				completedCommands.add(command);
			}
		}	
		catch(Exception e)
		{
			if(e.getMessage()==failMessage)
			{
				return dressOrder.append(", ").append(e.getMessage()).toString().substring(2);
			}
		}
		
		return dressOrder.toString().substring(2);
	}

	private static boolean isValidCommand(String command) throws Exception
	{
		// Pajamas must be taken off before anything else can be put on
		if (completedCommands.size() == 0)
		{                
			if (!command.equals	("8") )
			{
				throw new Exception(failMessage);
			}
		}

		//Only 1 piece of each type of clothing may be put on
		if (completedCommands.contains(command))
		{
			throw new Exception(failMessage);
		}

		//	You cannot put on socks when it is hot
		//	You cannot put on a jacket when it is hot
		if ((command.equals	("3")) || (command.equals("5")))    
		{
			if (dresser instanceof HotDresser)
			{
				throw new Exception(failMessage);
			}
		}
		//Socks must be put on before shoes
		//Pants must be put on before shoes
		else if (command.equals	("1"))
		{
			if (dresser instanceof HotDresser)
			{
				if (!completedCommands.contains("6"))
				{

					throw new Exception(failMessage);
				}
			}                
			else
			{
				if (!completedCommands.contains("3") || !completedCommands.contains("6"))
				{
					throw new Exception(failMessage);
				}
			}
		}

		//The shirt must be put on before the headwear or jacket
		else if ((command.equals("2")) || (command.equals("5")))
		{
			if (!completedCommands.contains("4"))
			{
				throw new Exception(failMessage);
			}
		}

		//You cannot leave the house until all items of clothing are on (except socks and a jacket when it�s hot)
		else if (command.equals	("7"))
		{
			if (!(dresser instanceof HotDresser))        
			{
				if (!completedCommands.contains("3") || !completedCommands.contains("5"))      
				{
					throw new Exception(failMessage);
				}
			}
			if (!completedCommands.contains("1") || !completedCommands.contains("2") || !completedCommands.contains("4") || !completedCommands.contains("6") || !completedCommands.contains("8"))
			{
				throw new Exception(failMessage);
			}
		}
		return true;
	}
}