package docusign;
/*
Author: Aditya Prabhu
Language: Java
 */
import java.util.Scanner;

public class Program 
{
	public static void main (String [] args)  
	{
		Scanner src = new Scanner(System.in);
		
		UserInput ui = new UserInput();
		System.out.println("Enter the Input");
	
		String 	input = src.nextLine();
		System.out.println("Input: "+input);
		
		System.out.println("Output: "+ui.acceptUserInput(input));
		src.close();
	}
}