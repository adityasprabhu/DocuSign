package docusign;
/*
Author: Aditya Prabhu
Language: Java
 */
public class HotDresser implements DresserInterface
{
	public String putOnFootwear()
	{
		return "sandals";
	}

	public String putOnHeadwear()
	{
		return "sun visor";
	}

	public String putOnSocks()
	{
		return "fail";
	}

	public String putOnShirt()
	{
		return "t-shirt";
	}

	public String putOnJacket()
	{
		return "fail";
	}

	public String putOnPants()
	{
		return "shorts";
	}

	public String leaveHouse()
	{
		return "leaving house";
	}

	public String takeOffPajamas()
	{
		return "Removing PJs";
	}
}