package docusign;
/*
Author: Aditya Prabhu
Language: Java
 */
import java.util.ArrayList;
import java.util.List;

public class UserInput 
{
	private static List<String> lst = new ArrayList<>();
	private DressService ds = new DressService();

	public String acceptUserInput(String input)
	{
		String [] inputarr = input.split(" ");
		String tempval=null;

		for(String val: inputarr)
		{
			tempval= val.trim().replaceAll(",","");
			if(!tempval.isEmpty())
			{
				lst.add(tempval);
			}
			tempval=null;
		}
		String out= ds.runService(lst);
		return out;
	}
}