package docusign;
/*
Author: Aditya Prabhu
Language: Java
 */
public interface DresserInterface 
{
   public String putOnFootwear();
   public String putOnHeadwear();
   public String putOnSocks();
   public String putOnShirt();
   public String putOnJacket();
   public String putOnPants();
   public String leaveHouse();
   public String takeOffPajamas();
}