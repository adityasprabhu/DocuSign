package docusign;
/*
Author: Aditya Prabhu
Language: Java
 */
public class ColdDresser implements DresserInterface
{
	public String putOnFootwear()
    {
        return "boots";
    }

    public String putOnHeadwear()
    {
        return "hat";
    }

    public String putOnSocks()
    {
        return "socks";
    }

    public String putOnShirt()
    {
        return "shirt";
    }

    public String putOnJacket()
    {
        return "jacket";
    }

    public String putOnPants()
    {
        return "pants";
    }

    public String leaveHouse()
    {
        return "leaving house";
    }

    public String takeOffPajamas()
    {
        return "Removing PJs";
    }
}